const logoImage = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663863872988/wXKHZdsyYNtAPIWm.png';

const articles = [
  {
    title: 'Cómo preparar tu manuscrito antes de enviarlo a la editorial',
    description: 'Organiza la estructura, el archivo, las notas y las fuentes para que el manuscrito llegue listo a una corrección profesional.',
    category: 'Manuscrito', reading: '6 min', image: '/manus-storage/blog-manuscrito_952372fe.jpg', imageAlt: 'Autor revisando las páginas de un manuscrito',
    route: '/blog/como-preparar-tu-manuscrito/', path: 'blog/como-preparar-tu-manuscrito',
    body: `
      <h2>Revisa la estructura antes de la ortografía</h2>
      <p>Antes de pulir cada coma, asegúrate de que la historia o el argumento tenga un inicio, un desarrollo y un cierre claros. Una estructura sólida ahorra horas de corrección posterior.</p>
      <h2>Organiza tu archivo</h2>
      <ul><li>Usa un solo documento con estilos definidos para títulos y capítulos.</li><li>Guarda copias de seguridad en la nube y en un disco externo.</li><li>Nombra los archivos de forma clara y con la fecha de la versión.</li></ul>
      <h2>Cuida las notas y las fuentes</h2>
      <p>Si tu libro cita fuentes o autores, conserva una lista ordenada de referencias. Facilita mucho la corrección y evita errores de atribución más adelante.</p>
      <h2>El paso final</h2>
      <p>Una vez que el texto esté cohesionado, llega el momento de la corrección profesional. Ese paso marca la diferencia entre un manuscrito prometedor y un libro listo para publicarse.</p>`
  },
  {
    title: 'Publicar en Amazon: guía práctica para autores independientes',
    description: 'Conoce los formatos de Amazon y lo que necesitas preparar para publicar tu libro sin hacer un tiraje ni mantener inventario.',
    category: 'Amazon', reading: '7 min', image: '/manus-storage/blog-amazon_89af3639.jpg', imageAlt: 'Lectura de un libro en formato digital',
    route: '/blog/publicar-en-amazon/', path: 'blog/publicar-en-amazon',
    body: `
      <h2>Por qué publicar en Amazon</h2>
      <p>Amazon es una de las vitrinas más grandes del mundo para un autor independiente. Permite vender en decenas de países sin necesidad de imprimir grandes tiradas ni de costear un almacén propio.</p>
      <h2>Los formatos disponibles</h2>
      <ul><li>eBook para lectura digital en cualquier dispositivo.</li><li>Tapa blanda impresa bajo demanda, sin inventario previo.</li><li>Libro en tapa dura en determinados mercados.</li></ul>
      <h2>Qué necesitas antes de publicar</h2>
      <p>Un manuscrito corregido, una maquetación profesional, una portada atractiva y un ISBN para el formato impreso. También conviene cuidar la descripción del libro y las palabras clave para que los lectores lo encuentren.</p>
      <h2>Cómo lo hacemos contigo</h2>
      <p>Publicamos tu libro en Amazon en formato eBook y tapa blanda, con su portada y su interior ya preparados. Verificamos cada detalle antes de ponerlo a la venta y te acompañamos en su difusión.</p>`
  },
  {
    title: 'Qué es el ISBN y cómo conseguir el tuyo',
    description: 'Qué es el ISBN, quién debe solicitarlo y cuál es la tarifa oficial vigente en Colombia para cada formato.',
    category: 'ISBN', reading: '5 min', image: '/manus-storage/blog-isbn_edf826c8.jpg', imageAlt: 'Detalles tipográficos y diseño de un libro',
    route: '/blog/que-es-isbn/', path: 'blog/que-es-isbn',
    body: `
      <h2>Qué es el ISBN y para qué sirve</h2>
      <p>El ISBN (Número Internacional Normalizado del Libro) es el identificador único de tu libro. Gracias a él, librerías, distribuidores y tiendas digitales pueden reconocer, registrar y vender tu obra sin confusiones.</p>
      <h2>En qué se diferencia del depósito legal</h2>
      <p>El depósito legal es la obligación de entregar ejemplares a una biblioteca nacional para conservar el patrimonio bibliográfico del país. Son dos trámites distintos y complementarios: uno identifica el libro, el otro lo archiva.</p>
      <h2>Quién debe solicitarlo</h2>
      <p>En Colombia, la solicitud debe quedar a nombre de la persona o entidad que responda legal y económicamente por la publicación. La Cámara Colombiana del Libro indica que no debe solicitarlo a su nombre un proveedor contratado para prestar servicios de edición.</p>
      <h2>Tarifa del ISBN en Colombia (2026)</h2>
      <p>Desde el 16 de enero de 2026, la tarifa oficial publicada por la Cámara Colombiana del Libro es COP $81.600 para ISBN impreso y COP $81.600 para ISBN digital, IVA incluido. El valor corresponde a cada versión registrada: COP $68.571 más COP $13.029 de IVA. Las tarifas pueden cambiar; verifica el monto vigente antes de pagar. Este es el trámite del ISBN, no el costo total de los servicios editoriales.</p>
      <h2>Cómo se consigue</h2>
      <ul><li>Cada país tiene una agencia nacional encargada de asignarlo.</li><li>En Colombia, se solicita antes de la impresión o de la publicación digital definitiva.</li><li>El mismo título publicado en formatos impreso y digital requiere un ISBN para cada versión.</li><li>La Cámara informa que la asignación puede tardar hasta dos días hábiles después del pago, si los datos están correctos.</li></ul>
      <h2>Nuestro acompañamiento</h2>
      <p>Te orientamos durante el trámite y el depósito legal; la solicitud debe registrarse a nombre de la persona o entidad responsable de la publicación. Consulta los <a href="https://camlibro.com.co/isbn/" target="_blank" rel="noopener noreferrer">requisitos y tarifas vigentes en la Cámara Colombiana del Libro</a>.</p>`
  },
  {
    title: 'Cómo proteger los derechos de tu libro antes de publicar',
    description: 'Qué derechos conservas sobre tu obra y qué revisar en una cesión antes de trabajar con cualquier editorial.',
    category: 'Derechos', reading: '6 min', image: '/manus-storage/blog-derechos_24db1924.jpg', imageAlt: 'Libro impreso sobre una mesa de lectura',
    route: '/blog/proteger-tus-derechos/', path: 'blog/proteger-tus-derechos',
    body: `
      <h2>Tu obra te pertenece desde el momento en que la escribes</h2>
      <p>El derecho de autor nace de forma automática cuando plasmas una idea original en un soporte, sea un archivo digital o un cuaderno. No necesitas registrar nada para ser el titular de tu obra; el registro solo sirve como prueba adicional.</p>
      <h2>Qué derechos conservas siempre</h2>
      <ul><li>El derecho moral: tu nombre siempre irá asociado a la obra y nadie puede modificarla sin tu permiso.</li><li>El derecho patrimonial: solo tú decides cómo, dónde y a qué precio se publica o se vende.</li><li>El derecho de reproducción y traducción: ninguna editorial puede reproducir ni traducir tu libro sin autorización por escrito.</li></ul>
      <h2>Qué revisar antes de firmar con cualquier editorial</h2>
      <p>Lee con calma qué cesión de derechos se pide, por cuánto tiempo y en qué territorios. Una cesión amplia y sin plazo puede impedirte publicar tu propio libro en el futuro. Pide siempre que la cesión sea específica y, si es posible, no exclusiva.</p>
      <h2>Nuestro compromiso con tu obra</h2>
      <p>En Búho Editorial el autor conserva el 100% de los derechos de su obra. Nunca registramos un libro a nombre de terceros y no cedemos tu propiedad intelectual sin tu autorización expresa.</p>`
  }
];

const serviceCards = [
  {
    name: 'Preparación del manuscrito',
    tagline: 'Tu texto, listo para el siguiente paso.',
    description: 'Revisión integral: corrección ortotipográfica, corrección de estilo y lectura editorial para dejar el manuscrito listo para publicarse.',
    usd: 'US$ 350', cop: 'COP 1.400.000'
  },
  {
    name: 'Maquetación',
    tagline: 'Una lectura que fluye.',
    description: 'Organizamos tipografía, márgenes y ritmo de lectura, adaptados a impresión y formato digital.',
    usd: 'US$ 250', cop: 'COP 1.000.000'
  },
  {
    name: 'Diseño de interiores',
    tagline: 'Cada página, con intención.',
    description: 'Estilos de título, capitulares, numeración y detalles gráficos para un interior tan cuidado como el contenido.',
    usd: 'US$ 200', cop: 'COP 800.000'
  },
  {
    name: 'Diseño de portada',
    tagline: 'La primera invitación a leer.',
    description: 'Una portada original y atractiva, pensada para tiendas digitales y librerías.',
    usd: 'US$ 180', cop: 'COP 720.000'
  },
  {
    name: 'ISBN y publicación en Amazon',
    tagline: 'De la identificación editorial a la publicación.',
    description: 'Te orientamos en la solicitud del ISBN a nombre de la persona o entidad legal y económicamente responsable de la publicación, y te acompañamos con el depósito legal y la publicación en Amazon en formato eBook y tapa blanda.',
    usd: 'US$ 220', cop: 'COP 880.000'
  }
].map((service, index) => `
  <article class="service-price-card" data-reveal>
    <span class="service-number">0${index + 1}</span>
    <div class="service-card-copy"><p class="eyebrow">SERVICIO EDITORIAL</p><h2>${service.name}</h2><h3>${service.tagline}</h3><p>${service.description}</p></div>
    <div class="service-card-prices"><span><b>USD</b><strong>${service.usd}</strong></span><span><b>COP</b><strong>${service.cop}</strong></span></div>
    <div class="service-card-action"><p>Precio orientativo; depende de la extensión y el estado del manuscrito.</p><a class="button button-outline" href="/contacto/?servicio=${encodeURIComponent(service.name)}">Cotizar este servicio <span aria-hidden="true">↗</span></a></div>
  </article>`).join('');

const servicesPage = {
  path: 'servicios', page: 'servicios', nav: 'servicios', title: 'Servicios editoriales para tu libro | Búho Editorial',
  description: 'Servicios editoriales claros y precios orientativos en USD y COP. Elige exactamente lo que tu libro necesita.',
  keywords: 'servicios editoriales, preparación de manuscrito, maquetación, portada, ISBN, Amazon', type: 'website',
  body: `
    <section class="services-page-hero container" data-reveal><p class="eyebrow"><span class="eyebrow-dot"></span> SERVICIOS EDITORIALES</p><h1>Todo lo que tu libro <em>necesita.</em></h1><p>Servicios claros, uno por uno, para que elijas exactamente lo que tu obra requiere en cada momento.</p></section>
    <figure class="services-photo container" data-reveal><img src="/manus-storage/async-images/vNI27X9iVjyTjurXYwxkoJ/image-2.webp" alt="Mesa de trabajo editorial con manuscrito y materiales de diseño" loading="lazy" /><figcaption>Un equipo editorial para acompañar cada etapa de tu libro.</figcaption></figure>
    <section class="container service-price-list" aria-label="Servicios editoriales y precios orientativos">${serviceCards}</section>
    <div class="container service-service-actions"><a class="button button-dark" href="/paquetes/">Ver paquetes completos <span aria-hidden="true">↗</span></a><a class="button button-outline" href="/contacto/">Consulta tu caso <span aria-hidden="true">↗</span></a></div>
    <section class="faq-section"><div class="container faq-layout"><div class="faq-heading" data-reveal><p class="eyebrow"><span class="eyebrow-dot"></span> PREGUNTAS FRECUENTES</p><h2>Dudas típicas de un autor.</h2><p>Las respuestas más pedidas antes de empezar. Si algo no queda claro, cuéntanos y lo conversamos contigo.</p><a class="button button-dark" href="/contacto/">Resuelve tu duda con nosotros <span aria-hidden="true">↗</span></a></div><div class="faq-list" data-reveal>
      <details><summary>¿Cuánto tiempo tarda publicar mi libro?</summary><div class="faq-answer"><p>El plazo estimado es de 30 a 70 días, según la extensión, el estado del manuscrito y el paquete. El cronograma de tu proyecto se confirma en la propuesta.</p><a href="/paquetes/">Ver paquetes y sus tiempos</a></div></details>
      <details><summary>¿Pierdo los derechos de mi obra?</summary><div class="faq-answer"><p>No. Conservas el 100% de los derechos de autor de tu obra. Nuestro trabajo es acompañarte en la edición y la publicación; nunca registramos tu libro a nombre de terceros ni cedemos tu propiedad intelectual sin tu autorización por escrito.</p><a href="/contacto/">Consúltanos por el formulario</a></div></details>
      <details><summary>¿Cómo puedo pagar los servicios?</summary><div class="faq-answer"><p>Puedes pagar en dólares, pesos colombianos o pesos mexicanos. Trabajamos con pago por transferencia bancaria y otros medios acordados según tu país. Cotizamos cada proyecto por escrito, sin costos ocultos ni sorpresas al final.</p><a href="/contacto/">Pregúntanos por los medios de pago</a></div></details>
      <details><summary>¿Qué es el ISBN y por qué lo necesito?</summary><div class="faq-answer"><p>El ISBN es el número internacional que identifica tu libro como una publicación única y permite su venta y distribución, por ejemplo, en Amazon y librerías. En Colombia, te orientamos para solicitarlo a nombre de la persona o entidad legal y económicamente responsable de la publicación.</p><a href="/paquetes/">Ver paquetes con ISBN incluido</a></div></details>
      <details><summary>¿Cuánto cuesta el trámite del ISBN en Colombia?</summary><div class="faq-answer"><p>La tarifa oficial publicada desde el 16 de enero de 2026 es COP $81.600 por ISBN impreso o digital, IVA incluido (COP $68.571 más COP $13.029 de IVA por versión). Las tarifas pueden cambiar; confirma el valor vigente antes de pagar. Este es el costo del trámite y no el total de un servicio editorial; la propuesta detalla qué incluye cada servicio.</p><a href="https://camlibro.com.co/isbn/" target="_blank" rel="noopener noreferrer">Consultar tarifas vigentes en la Cámara Colombiana del Libro</a></div></details>
      <details><summary>¿Mi libro quedará disponible en Amazon?</summary><div class="faq-answer"><p>Sí. Publicamos en Amazon en formato eBook y tapa blanda, con portada e interior preparados profesionalmente. No hay un tiraje fijo prometido: las copias impresas se producen bajo demanda o se cotizan por separado, según el caso.</p><a href="/paquetes/">Ver paquetes con publicación en Amazon</a></div></details>
      <details><summary>¿Puedo contratar solo un servicio?</summary><div class="faq-answer"><p>Claro. Puedes contratar servicios por separado —corrección, maquetación, diseño de portada, ISBN o publicación— o elegir un paquete que reúna varios. Decides qué necesita tu obra en cada momento.</p><a href="/contacto/">Cuéntanos qué servicio necesitas</a></div></details>
      <details><summary>¿Qué revisiones incluye el trabajo?</summary><div class="faq-answer"><p>Las rondas y los ajustes se acuerdan en la propuesta de tu proyecto. Te mostramos la maquetación y la portada antes de publicar, para que puedas aprobarlas.</p><a href="/paquetes/">Ver qué incluye cada paquete</a></div></details>
      <details><summary>¿Publican mi manuscrito sin mi permiso?</summary><div class="faq-answer"><p>Nunca. No publicamos, reproducimos ni compartimos tu manuscrito sin autorización expresa. El acceso queda limitado al equipo que trabaja directamente en tu proyecto y puedes solicitar que eliminemos tus archivos cuando el servicio termine.</p><a href="/terminos/">Leer términos y condiciones</a></div></details>
    </div></div></section>
    <section class="closing-cta container" data-reveal><p class="eyebrow">TU LIBRO TE ESTÁ ESPERANDO</p><h2>Empecemos a publicar tu obra hoy mismo.</h2><p>Cuéntanos sobre tu manuscrito y recibe una propuesta personalizada en menos de 48 horas, sin compromiso.</p><a class="button button-dark" href="/contacto/">Cotiza tu libro <span aria-hidden="true">↗</span></a><a class="button button-outline" href="/paquetes/">Ver paquetes</a></section>`
};

function articlePage(article) {
  return `
  <section class="article-intro container" data-reveal>
    <a class="article-back" href="/blog/">← Volver al blog</a>
    <p class="eyebrow"><span class="eyebrow-dot"></span> ${article.category.toUpperCase()}</p>
    <h1>${article.title}</h1>
    <p class="article-byline">${article.reading} de lectura · Equipo Búho Editorial</p>
  </section>
  <article class="article-content container" aria-label="${article.title}">
    <figure class="article-lead-image"><img src="${article.image}" alt="${article.imageAlt}" /></figure>
    <div class="article-text">${article.body}</div>
    <section class="article-cta" data-reveal><p class="eyebrow">TU LIBRO TE ESTÁ ESPERANDO</p><h2>Tu historia merece ser publicada con cuidado.</h2><p>Conversemos sobre lo que necesitas, a tu ritmo y sin compromiso.</p><a class="button button-dark" href="/contacto/">Cuéntanos sobre tu libro <span aria-hidden="true">↗</span></a></section>
  </article>`;
}

const pages = [
  servicesPage,
  {
    path: 'libros', page: 'libros', nav: 'libros', title: 'Libros publicados | Búho Editorial',
    description: 'Conoce los libros que han confiado en Búho Editorial y descubre cómo acompañamos nuevas historias.',
    keywords: 'libros publicados, autores hispanohablantes, Búho Editorial, autopublicación',
    type: 'website', body: `
    <section class="library-intro container" data-reveal><p class="eyebrow"><span class="eyebrow-dot"></span> NUESTROS AUTORES</p><h1>Libros publicados</h1><p>Descubre las obras que hemos acompañado desde el primer borrador hasta llegar a manos de sus lectores en todo el mundo.</p></section>
    <section class="container library-grid" aria-label="Libros publicados por Búho Editorial">
      <article class="book-card" data-reveal><div class="book-cover"><img src="/manus-storage/libro-amor-tu-olor_7fc27172.png" alt="Portada del libro Amo tu olor, de Styven Mogrovejo" loading="lazy" /></div><div class="book-meta"><p class="eyebrow">UNA HISTORIA PUBLICADA</p><h2>Amo tu olor</h2><p class="book-author">Styven Mogrovejo</p><p>Una de las obras acompañadas por Búho Editorial.</p></div></article>
    </section>
    <section class="closing-cta container" data-reveal><p class="eyebrow">TU LIBRO TE ESTÁ ESPERANDO</p><h2>Empecemos a publicar tu obra hoy mismo.</h2><p>Cuéntanos sobre tu manuscrito y recibe una propuesta personalizada en menos de 48 horas, sin compromiso.</p><a class="button button-dark" href="/contacto/">Cotiza tu libro <span aria-hidden="true">↗</span></a> <a class="button button-outline" href="/paquetes/">Ver paquetes</a></section>`
  },
  {
    path: 'blog', page: 'blog', nav: 'blog', title: 'Blog de autopublicación | Búho Editorial',
    description: 'Guías prácticas sobre derechos de autor, ISBN, publicación en Amazon y preparación del manuscrito.',
    keywords: 'blog de autopublicación, manuscrito, Amazon, ISBN, derechos de autor',
    type: 'website', body: `
    <section class="journal-intro container" data-reveal><p class="eyebrow"><span class="eyebrow-dot"></span> BLOG EDITORIAL</p><h1>Ideas para publicar tu libro.</h1><p>Guías claras sobre derechos de autor, ISBN, publicación en Amazon y la preparación del manuscrito, escritas para autores que quieren dar el paso.</p></section>
    <section class="container journal-grid" aria-label="Artículos de Búho Editorial">
      ${articles.map((article) => `<article class="journal-card" data-reveal><a class="journal-card-image" href="${article.route}" aria-label="Leer: ${article.title}"><img src="${article.image}" alt="${article.imageAlt}" loading="lazy" /></a><div class="journal-card-body"><p class="eyebrow">${article.category.toUpperCase()}</p><h2><a href="${article.route}">${article.title}</a></h2><p>${article.description}</p><a class="journal-read-link" href="${article.route}">Leer artículo · ${article.reading} <span aria-hidden="true">↗</span></a></div></article>`).join('\n')}
    </section>
    <section class="closing-cta container" data-reveal><p class="eyebrow">TU LIBRO TE ESTÁ ESPERANDO</p><h2>Empecemos a publicar tu obra hoy mismo.</h2><p>Cuéntanos sobre tu manuscrito y recibe una propuesta personalizada en menos de 48 horas, sin compromiso.</p><a class="button button-dark" href="/contacto/">Cotiza tu libro <span aria-hidden="true">↗</span></a> <a class="button button-outline" href="/paquetes/">Ver paquetes</a></section>`
  },
  ...articles.map((article) => ({
    path: article.path, page: 'articulo', nav: 'blog', title: `${article.title} | Búho Editorial`,
    description: article.description, keywords: `${article.category.toLowerCase()}, autopublicación, Búho Editorial, publicar un libro`, type: 'article', body: articlePage(article)
  })),
  {
    path: 'aviso-privacidad', page: 'legal', nav: null, title: 'Aviso de privacidad | Búho Editorial',
    description: 'Consulta cómo Búho Editorial protege tus datos, tu manuscrito y los derechos de tu obra.',
    keywords: 'aviso de privacidad, datos personales, derechos de autor, Búho Editorial', type: 'website',
    body: `
    <section class="legal-intro container" data-reveal><p class="eyebrow"><span class="eyebrow-dot"></span> LEGAL</p><h1>Aviso de privacidad</h1><p>En Búho Editorial cuidamos la información de los autores que confían en nosotros. Este aviso explica qué datos recopilamos, para qué los usamos y cómo protegemos tu privacidad y tu obra.</p><p class="legal-updated">Última actualización: 11 de octubre de 2026</p></section>
    <div class="legal-content container"><article class="legal-document">
      <h2>Responsable del tratamiento</h2><p>Búho Editorial es responsable del tratamiento de los datos personales que nos compartes a través de este sitio web, por correo electrónico o por WhatsApp. Puedes contactarnos en <a href="mailto:infobuhoeditorial@gmail.com">infobuhoeditorial@gmail.com</a>.</p>
      <h2>Datos que recopilamos</h2><ul><li>Nombre y apellidos.</li><li>Correo electrónico.</li><li>Número de teléfono o WhatsApp.</li><li>País y ciudad de residencia.</li><li>Información sobre tu obra: título, género, extensión y el manuscrito cuando decides compartirlo.</li><li>Paquete de servicios de tu interés.</li></ul>
      <h2>Para qué usamos tus datos</h2><ul><li>Responder tus consultas y enviarte propuestas personalizadas.</li><li>Prestarte los servicios editoriales que contratas.</li><li>Gestionar la comunicación durante el proceso de publicación.</li><li>Enviarte información relevante sobre tu proyecto.</li><li>Cumplir con obligaciones legales y contables.</li></ul>
      <h2>Conservación de los derechos del autor</h2><p>Tu obra siempre es tuya. Al contratar nuestros servicios no cedemos ni transferimos la propiedad intelectual de tu manuscrito.</p><ul><li>Conservas el 100% de los derechos de autor de tu obra.</li><li>No publicamos, reproducimos ni compartimos tu manuscrito sin tu autorización expresa.</li><li>No registramos tu obra a tu nombre ni a nombre de terceros sin tu consentimiento por escrito.</li><li>Puedes solicitar la eliminación de tus archivos una vez finalizado el servicio.</li></ul>
      <h2>Conservación de los datos</h2><p>Conservamos tus datos personales mientras exista una relación comercial o mientras sea necesario para cumplir fines legales y contables. Cuando dejan de ser necesarios, los eliminamos de forma segura.</p>
      <h2>Tus derechos</h2><p>Puedes solicitar en cualquier momento el acceso, la corrección, la actualización o la eliminación de tus datos personales escribiéndonos a <a href="mailto:infobuhoeditorial@gmail.com">infobuhoeditorial@gmail.com</a>. Atenderemos tu solicitud en un plazo máximo de 15 días hábiles.</p>
      <h2>Seguridad de la información</h2><p>Aplicamos medidas técnicas y organizativas razonables para proteger tus datos frente a accesos no autorizados, pérdida o alteración. El acceso a tu manuscrito queda limitado al equipo que trabaja directamente en tu proyecto.</p>
      <h2>Formularios y proveedor de envío</h2><p>Los formularios de cotización y solicitud de videollamada usan FormSubmit para procesar y reenviar el mensaje a <a href="mailto:infobuhoeditorial@gmail.com">infobuhoeditorial@gmail.com</a>. Al enviarlos, la información que escribes se comparte con ese proveedor con el propósito de entregar tu solicitud. No envíes información sensible que no sea necesaria para responderte.</p>
      <h2>Menores de edad</h2><p>Nuestros servicios están dirigidos a personas mayores de edad. Si una persona menor desea publicar, requerimos la autorización de su padre, madre o tutor legal.</p>
      <h2>Cambios a este aviso</h2><p>Podemos actualizar este aviso de privacidad para reflejar cambios en nuestras prácticas o en la normativa aplicable. Publicaremos cualquier cambio en esta misma página.</p>
      <h2>Contacto</h2><p>Si tienes dudas sobre el tratamiento de tus datos o sobre la protección de tu obra, escríbenos a <a href="mailto:infobuhoeditorial@gmail.com">infobuhoeditorial@gmail.com</a> o por <a href="https://wa.me/573116984131">WhatsApp al +57 311 698 4131</a>.</p>
      <p><a href="/terminos/">Ver términos y condiciones</a></p>
    </article></div>`
  },
  {
    path: 'terminos', page: 'legal', nav: null, title: 'Términos y condiciones | Búho Editorial',
    description: 'Conoce las condiciones de cotización, pago, derechos, producción editorial y publicación de Búho Editorial.',
    keywords: 'términos y condiciones, servicios editoriales, derechos de autor, Búho Editorial', type: 'website',
    body: `
    <section class="legal-intro container" data-reveal><p class="eyebrow"><span class="eyebrow-dot"></span> LEGAL</p><h1>Términos y condiciones</h1><p>Estos términos regulan la contratación de los servicios editoriales de Búho Editorial. Al solicitar una cotización o contratar un paquete, aceptas las condiciones descritas a continuación.</p><p class="legal-updated">Última actualización: 11 de octubre de 2026</p></section>
    <div class="legal-content container"><article class="legal-document">
      <h2>Objeto del servicio</h2><p>Búho Editorial presta servicios de preparación del manuscrito, maquetación, diseño de interiores, diseño de portada, gestión del ISBN y publicación en Amazon para autores hispanohablantes.</p>
      <h2>Propiedad intelectual y derechos del autor</h2><p>El autor conserva en todo momento la titularidad de su obra.</p><ul><li>El autor mantiene el 100% de los derechos de autor sobre su obra.</li><li>Búho Editorial no adquiere regalías ni derechos sobre las ventas del libro.</li><li>El autor otorga únicamente una autorización temporal para editar, maquetar y publicar su obra como parte del servicio contratado.</li><li>Búho Editorial no registrará la obra a su nombre ni a nombre de terceros.</li></ul>
      <h2>Cotizaciones y contratación</h2><p>Las cotizaciones son personalizadas y tienen una vigencia de 30 días calendario. El servicio se considera contratado cuando el autor aprueba la propuesta y realiza el pago correspondiente.</p>
      <h2>Pagos</h2><p>Los precios se publican en dólares estadounidenses (USD), pesos colombianos (COP) y pesos mexicanos (MXN), y corresponden a un pago único por el paquete elegido. Pregúntanos por planes de pago cuando necesites fraccionar el valor.</p>
      <h2>Responsabilidades del autor</h2><ul><li>Entregar el manuscrito completo y en el formato acordado.</li><li>Garantizar que la obra es de su autoría y no vulnera derechos de terceros.</li><li>Responder con prontitud a las revisiones y aprobaciones solicitadas.</li><li>Revisar y aprobar la portada y las pruebas finales antes de la publicación.</li></ul>
      <h2>Plazos de entrega</h2><p>El plazo estimado de producción es de 30 a 70 días, según el paquete y el estado del manuscrito. El tiempo definitivo se confirma en cada propuesta y comienza a contar desde la recepción del pago y del manuscrito completo. Los retrasos por parte del autor extienden proporcionalmente los plazos.</p>
      <h2>Revisiones y correcciones</h2><p>Cada paquete incluye el número de rondas de revisión indicado en su descripción. Las correcciones adicionales o los cambios de alcance se cotizan por separado.</p>
      <h2>Impresión de ejemplares</h2><p>Los paquetes no incluyen ni garantizan un número fijo de ejemplares impresos. Si solicitas impresión física, la cantidad, disponibilidad, costo y logística se cotizarán y acordarán contigo por separado antes de iniciar esa parte del proyecto.</p>
      <h2>Cancelaciones y reembolsos</h2><p>Si el autor cancela antes de iniciar la producción, se reembolsa el valor pagado menos los gastos administrativos. Una vez iniciado el trabajo editorial, el reembolso se calcula según el avance real del proyecto.</p>
      <h2>Publicación y distribución</h2><p>La publicación en Amazon se realiza en las plataformas y territorios acordados. Búho Editorial no garantiza cifras de ventas ni resultados comerciales específicos.</p>
      <h2>Uso de la obra como referencia</h2><p>Solo con la autorización del autor podremos mencionar su libro o su nombre en nuestro portafolio, redes sociales o materiales promocionales.</p>
      <h2>Modificaciones</h2><p>Búho Editorial puede actualizar estos términos para reflejar cambios en sus servicios o en la normativa aplicable. La versión vigente será siempre la publicada en esta página.</p>
      <h2>Contacto</h2><p>Para dudas sobre estos términos, escríbenos a <a href="mailto:infobuhoeditorial@gmail.com">infobuhoeditorial@gmail.com</a> o por <a href="https://wa.me/573116984131">WhatsApp al +57 311 698 4131</a>. <a href="/contacto/">Escríbenos</a> · <a href="/aviso-privacidad/">Ver aviso de privacidad</a>.</p>
    </article></div>`
  }
];

export { articles, logoImage };
export default pages;
