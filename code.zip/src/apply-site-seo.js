import { existsSync } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import pages, { logoImage } from './secondary-pages.js';

const root = process.cwd();
const publicOrigin = 'https://buhoeditoria-zuqkghpp.manus.space';
const exactHomeTitle = 'Búho Editorial';
const exactHomeDescription = 'Editorial independiente para autores hispanohablantes. Te acompañamos con edición, diseño y autopublicación para dar vida a tu libro.';
const companyDescription = 'Búho Editorial es una editorial digital e independiente dedicada a la edición, maquetación y autopublicación de libros de autores emergentes. Nuestro objetivo es impulsar el talento literario ofreciendo servicios editoriales de alta calidad.';
const publicPages = [...new Set([
  'index.html',
  'servicios/index.html',
  'paquetes/index.html',
  'nosotros/index.html',
  'contacto/index.html',
  ...pages.map((page) => `${page.path}/index.html`),
])];
const metadataPattern = /<meta\s+(?:name|property)=["'](?:description|application-name|apple-mobile-web-app-title|robots|og:type|og:title|og:description|og:url|og:site_name|og:image|og:image:alt|twitter:card|twitter:title|twitter:description|twitter:image)["'][^>]*\/?\s*>\s*/gi;
const iconPattern = /<link\b(?=[^>]*\brel=["'](?:icon|shortcut icon|apple-touch-icon|manifest)["'])[^>]*\/?>\s*/gi;
const canonicalPattern = /<link\b(?=[^>]*\brel=["']canonical["'])[^>]*\/?>\s*/gi;
const schemaPattern = /<script\s+id=["']buho-site-identity["'][^>]*>[\s\S]*?<\/script>\s*/gi;

const getTagContent = (html, tagName) => html.match(new RegExp(`<${tagName}\\b[^>]*>([\\s\\S]*?)<\\/${tagName}>`, 'i'))?.[1]?.trim() || '';
const getMeta = (html, key, attribute = 'name') => {
  const escaped = key.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&');
  return html.match(new RegExp(`<meta\\s+${attribute}=["']${escaped}["']\\s+content=["']([^"']*)["'][^>]*>`, 'i'))?.[1] || '';
};
const escapeAttribute = (value) => String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const logoUrl = new URL(logoImage, `${publicOrigin}/`).toString();

const identitySchema = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'Organization',
      name: 'Búho Editorial',
      founder: { '@type': 'Person', name: 'Styven Mogrovejo' },
      url: `${publicOrigin}/`,
      description: companyDescription,
      logo: logoUrl,
      email: 'infobuhoeditorial@gmail.com',
      telephone: '+57 311 698 4131',
      areaServed: ['Colombia', 'México', 'Estados Unidos', 'autores hispanohablantes'],
      sameAs: ['https://instagram.com/editorial_buho', 'https://www.tiktok.com/@buho_editorial'],
      contactPoint: {
        '@type': 'ContactPoint',
        contactType: 'atención editorial',
        email: 'infobuhoeditorial@gmail.com',
        telephone: '+57 311 698 4131',
        availableLanguage: ['Spanish'],
      },
    },
    {
      '@type': 'WebSite',
      name: 'Búho Editorial',
      url: `${publicOrigin}/`,
      description: exactHomeDescription,
      inLanguage: 'es',
    },
  ],
};
const schemaScript = `<script id="buho-site-identity" type="application/ld+json">${JSON.stringify(identitySchema).replace(/</g, '\\u003c')}</script>`;
const faviconLinks = [
  '<link rel="icon" type="image/png" sizes="512x512" href="/favicon-512.png" />',
  '<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />',
  '<link rel="manifest" href="/site.webmanifest" />',
].join('\n  ');

for (const relativePath of publicPages) {
  const file = resolve(root, relativePath);
  if (!existsSync(file)) throw new Error(`Falta la página SEO pública: ${relativePath}`);

  let html = await readFile(file, 'utf8');
  let title = getTagContent(html, 'title');
  let description = getMeta(html, 'description');
  const type = getMeta(html, 'og:type', 'property') || 'website';
  if (!title || !description || !html.includes('</head>')) {
    throw new Error(`Faltan metadatos o head HTML en ${relativePath}`);
  }

  const isHome = relativePath === 'index.html';
  const publicRoute = isHome ? '/' : `/${relativePath.replace(/\/index\.html$/, '/')}`;
  const pageUrl = `${publicOrigin}${publicRoute}`;
  if (isHome) {
    title = exactHomeTitle;
    description = exactHomeDescription;
    if (!html.includes(companyDescription)) {
      const intro = /(<p class="hero-intro">[\s\S]*?<\/p>)/i;
      if (!intro.test(html)) throw new Error('No se encontró el hero para el texto descriptivo de la organización.');
      html = html.replace(intro, `$1\n        <p class="hero-description">${companyDescription}</p>`);
    }
  }

  html = html.replace(/<title\b[^>]*>[\s\S]*?<\/title>/i, `<title>${escapeAttribute(title)}</title>`);
  html = html.replace(metadataPattern, '').replace(iconPattern, '').replace(canonicalPattern, '').replace(schemaPattern, '');
  const descriptionText = escapeAttribute(description);
  const titleText = escapeAttribute(title);
  const metadata = [
    `<link rel="canonical" href="${escapeAttribute(pageUrl)}" />`,
    '<meta name="application-name" content="Búho Editorial" />',
    '<meta name="apple-mobile-web-app-title" content="Búho Editorial" />',
    '<meta name="robots" content="index,follow,max-image-preview:large" />',
    `<meta name="description" content="${descriptionText}" />`,
    `<meta property="og:type" content="${escapeAttribute(type)}" />`,
    `<meta property="og:site_name" content="Búho Editorial" />`,
    `<meta property="og:url" content="${escapeAttribute(pageUrl)}" />`,
    `<meta property="og:title" content="${titleText}" />`,
    `<meta property="og:description" content="${descriptionText}" />`,
    `<meta property="og:image" content="${escapeAttribute(logoUrl)}" />`,
    '<meta property="og:image:alt" content="Logotipo de Búho Editorial" />',
    '<meta name="twitter:card" content="summary_large_image" />',
    `<meta name="twitter:title" content="${titleText}" />`,
    `<meta name="twitter:description" content="${descriptionText}" />`,
    `<meta name="twitter:image" content="${escapeAttribute(logoUrl)}" />`,
  ].join('\n  ');
  const identity = `${metadata}\n  ${faviconLinks}${isHome ? `\n  ${schemaScript}` : ''}`;
  html = html.replace('</head>', `${identity}\n</head>`);
  await writeFile(file, html, 'utf8');
  console.log(`SEO Búho aplicado: ${relativePath}`);
}
