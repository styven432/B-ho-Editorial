import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import pages from './secondary-pages.js';
import { logoImage } from './secondary-pages.js';

const root = process.cwd();
const serviceHtml = await readFile(resolve(root, 'servicios/index.html'), 'utf8');
const header = serviceHtml.match(/<header\b[\s\S]*?<\/header>/)?.[0];
const footer = serviceHtml.match(/<footer\b[\s\S]*?<\/footer>/)?.[0];

if (!header || !footer) {
  throw new Error('No se encontró la navegación o el pie en servicios/index.html.');
}

const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
})[character]);

for (const page of pages) {
  const pageHeader = header.replace(/\saria-current="page"/g, '').replace(
    `href="/${page.nav ?? 'servicios'}/"`,
    `href="/${page.nav ?? 'servicios'}/"${page.nav ? ' aria-current="page"' : ''}`
  );
  const document = `<!doctype html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="google-site-verification" content="-q7Zk1OxKpBXQkjJYQxkRTu4e6WnkZwiJIS0c3C9LEc" />
  <meta name="theme-color" content="#f2f7fb" />
  <title>${escapeHtml(page.title)}</title>
  <meta name="description" content="${escapeHtml(page.description)}" />
  <meta name="keywords" content="${escapeHtml(page.keywords)}" />
  <meta property="og:type" content="${escapeHtml(page.type)}" />
  <meta property="og:title" content="${escapeHtml(page.title)}" />
  <meta property="og:description" content="${escapeHtml(page.description)}" />
  <meta property="og:site_name" content="Búho Editorial" />
  <meta property="og:image" content="${logoImage}" />
  <meta property="og:image:alt" content="Logotipo de Búho Editorial" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="${escapeHtml(page.title)}" />
  <meta name="twitter:description" content="${escapeHtml(page.description)}" />
  <meta name="twitter:image" content="${logoImage}" />
</head>
<body data-page="${escapeHtml(page.page)}">
  <a class="skip-link" href="#contenido">Saltar al contenido</a>
  ${pageHeader}
  <main id="contenido" class="generated-page ${escapeHtml(page.page)}-page">${page.body}</main>
  ${footer}
  <script type="module" src="/src/main.js"></script>
</body>
</html>
`;
  const outputPath = join(root, page.path, 'index.html');
  await mkdir(dirname(outputPath), { recursive: true });
  await writeFile(outputPath, document, 'utf8');
  console.log(`Generada ${page.path}/index.html`);
}
