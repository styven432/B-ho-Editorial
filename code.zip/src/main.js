import './styles.css';

const toggle = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#primary-navigation');

function closeMenu() {
  if (!toggle || !navigation) return;
  toggle.setAttribute('aria-expanded', 'false');
  navigation.classList.remove('is-open');
  toggle.querySelector('.sr-only').textContent = 'Abrir menú';
}

if (toggle && navigation) {
  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    navigation.classList.toggle('is-open', open);
    toggle.querySelector('.sr-only').textContent = open ? 'Cerrar menú' : 'Abrir menú';
  });
  navigation.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeMenu();
  });
  document.addEventListener('click', (event) => {
    if (toggle.getAttribute('aria-expanded') === 'true' && !navigation.contains(event.target) && !toggle.contains(event.target)) closeMenu();
  });
}

const revealed = document.querySelectorAll('[data-reveal]');
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        currentObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -28px 0px' });
  revealed.forEach((element) => observer.observe(element));
} else {
  revealed.forEach((element) => element.classList.add('is-visible'));
}

const packageSelect = document.querySelector('#paquete');
if (packageSelect) {
  const requestedPackage = new URLSearchParams(window.location.search).get('paquete');
  if (requestedPackage && Array.from(packageSelect.options).some((option) => option.value === requestedPackage || option.textContent.trim() === requestedPackage)) {
    packageSelect.value = requestedPackage;
  }
}

const preferredDate = document.querySelector('#asesoria-fecha');
if (preferredDate) {
  const localToday = new Date();
  localToday.setMinutes(localToday.getMinutes() - localToday.getTimezoneOffset());
  preferredDate.min = localToday.toISOString().slice(0, 10);
}

const returnStatus = document.querySelector('#form-status');
const sentType = new URLSearchParams(window.location.search).get('enviado');
const thankYouMessages = {
  cotizacion: '¡Gracias por escribirnos! Tu solicitud de cotización fue enviada a Búho Editorial. Te responderemos por correo en menos de 48 horas; también recibirás un acuse automático.',
  videollamada: '¡Gracias por solicitar una asesoría gratuita! Recibimos tu preferencia de fecha y hora. Te confirmaremos la disponibilidad por correo y recibirás un acuse automático.',
};
if (returnStatus && thankYouMessages[sentType]) {
  returnStatus.textContent = thankYouMessages[sentType];
  returnStatus.hidden = false;
}

document.querySelectorAll('form[data-auto-reply]').forEach((form) => {
  form.addEventListener('submit', () => {
    const mode = form.dataset.autoReply;
    const nameField = form.querySelector('[name="Nombre"]');
    const name = (nameField?.value || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 100);
    const greeting = name ? `¡Hola, ${name}!` : '¡Hola!';
    const response = form.querySelector('[name="_autoresponse"]');
    const next = form.querySelector('[name="_next"]');

    if (response && mode === 'cotizacion') {
      response.value = `${greeting} Gracias por escribir a Búho Editorial. Recibimos tu solicitud de cotización y te responderemos en menos de 48 horas al correo que compartiste. —Equipo Búho Editorial`;
    } else if (response && mode === 'videollamada') {
      response.value = `${greeting} Gracias por solicitar una asesoría gratuita con Búho Editorial. Recibimos tu solicitud. La fecha y hora que propones son preferencias; te confirmaremos disponibilidad por correo. —Equipo Búho Editorial`;
    }

    if (next) {
      const returnUrl = new URL('/contacto/', window.location.origin);
      returnUrl.searchParams.set('enviado', mode);
      next.value = returnUrl.href;
    }
  });
});
