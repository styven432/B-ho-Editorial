# Plan del sitio — Búho Editorial

## Estado y alcance aprobado

Continuar el sitio existente en `/home/ubuntu/buhoeditorial`, construido como sitio multipágina con HTML generado por Vite y servidor Node/Express en contenedor. El usuario autorizó activar servidor y base de datos; ambos siguen encendidos y son de activación irreversible. El editor anterior se canceló y ningún cambio de libro o testimonio se somete a escritura durante pruebas. El usuario reanudó después y pidió expresamente un panel privado para administrar y publicar cambios. La base gestionada comparte datos entre Preview y Producción: no usar escrituras de prueba ni borrar información.

El producto público conserva las páginas y contenidos de Búho Editorial replicados de su sitio SITE123, las tarifas efectivamente publicadas salvo el precio base modificado explícitamente a MXN 400, los servicios y derechos del autor, sin prometer tirajes físicos. Se mantiene la identidad visual de la referencia. WhatsApp es personal y queda sin respuestas automáticas; el sitio mantiene enlaces manuales. Los formularios web usan FormSubmit y acuses de correo personalizados; la primera recepción del destinatario requiere confirmar el mensaje de activación de FormSubmit.

Este alcance actualizado añade dos resultados solicitados ahora: optimizar el nombre/logotipo/metadatos del sitio para Google y buscadores de IA; y crear `/admin/`, una consola para que el único administrador de la cuenta Manus pueda modificar el contenido y las imágenes del sitio, guardar borradores y publicarlos. El editor cubrirá textos y módulos de Inicio, Servicios, Paquetes, Nosotros y Testimonios, Libros/portadas, Blog/artículos, Contacto y videollamada, enlaces/canales del pie, avisos y términos, SEO y colores. Sólo el contenido marcado como publicado se hace público. Las imágenes de autores/testimonios serán fotos reales que proporcione/seleccione el administrador; nunca se fabrican testimonios.

## Enfoque técnico

- Mantener HTML multirruta del sitio como contenido significativo antes de ejecutar JavaScript, Vite para build y Node 22 en contenedor para producción.
- Extender `server.js` con endpoints JSON, autenticación Manus OAuth y persistencia en la base MySQL gestionada. Mantener la entrega de HTML estático y `/_app/health`.
- Mantener una sola identidad de administradora: validar el email de la sesión Manus contra el secreto protegido `BUHO_ADMIN_EMAIL`; no almacenar contraseñas ni claves en el repositorio. Obtener por OAuth el `openId`, el email y la información de usuario desde los endpoints Manus indicados en el skill. El botón del panel inicia OAuth y la pantalla de login no revela si otras cuentas existen.
- Firmar la cookie `webdev_app_session` con `MANUS_JWT_SECRET`; para el Preview cruzado usar `SameSite=None; Secure; HttpOnly`, validar firma, `appId`, expiración y el `openId` frente a la única cuenta autorizada. Proteger mutaciones con verificación de origen/CSRF, límites y validación de entradas.
- Crear sólo una migración idempotente no destructiva `CREATE TABLE IF NOT EXISTS` para documento/contenido versionado. Inicializar borrador/publicado con la versión fiel al sitio actual mediante inserción condicionada a que no exista la fila; nunca reemplazar contenido persistido al reiniciar. Mantener versión pública y borrador separadas, con comparación/registro de cambios.
- Implementar CRUD autenticado del catálogo de libros/portadas, Blog/artículos, testimonios con texto y retrato, servicios/paquetes/FAQ, copy por página, imagen de fundador, canales/contacto, footer y avisos/SEO. Agregar, editar, ordenar y quitar elementos, cargando imágenes JPEG/PNG/WebP validadas (peso limitado) en almacenamiento administrado. Quitar una imagen la retira de la web y de su registro público; no borrar objetos históricos del almacenamiento desde pruebas.
- Renderizar únicamente contenido publicado a visitantes; exponer borradores y operaciones de escritura sólo detrás del check de administrador. El panel y rutas/API de autenticación llevan `noindex` y nunca aparecen en sitemap público. Botón «Guardar borrador» no publica; botón «Publicar cambios» exige confirmación clara antes de sustituir la versión pública.
- Mantener WhatsApp como enlace de contacto manual. No prometer respuesta automática de WhatsApp personal ni activarla.
- Preservar el envío FormSubmit de las solicitudes de cotización/asesoría, respuesta personalizada por nombre por correo, confirmación visual del retorno y activación inicial por parte del titular. No enviar formularios falsos para probarlos.

## Identidad y SEO

Aplicar nombre de sitio consistente `Búho Editorial` en título, descripción, `application-name`, `og:site_name`, Twitter Cards y datos estructurados `Organization`/`WebSite`; mantener la verificación de Search Console ya proporcionada. Para Inicio, el `<title>` debe ser exactamente `Búho Editorial`; la descripción corta es `Editorial independiente para autores hispanohablantes. Te acompañamos con edición, diseño y autopublicación para dar vida a tu libro.`. Las otras rutas públicas conservan títulos/descripciones útiles y propios con la marca; sus metadatos de redes reflejan su contenido.

El JSON-LD de `Organization` identifica como fundador a Styven Mogrovejo. Crear iconos a partir del logo que entregó el usuario y enlazarlos desde todas las páginas. El PNG cuadrado de 512×512 px es el favicon explícito; el endpoint `/favicon.ico` del gateway no sirve el archivo ICO del proyecto, por lo que no se debe usar como enlace preferido. `app.config.ts.logoUrl` es la identidad independiente del proyecto.

Usar como origen real `https://buhoeditoria-zuqkghpp.manus.space/` para las URLs canónicas y `og:url`; el gateway sirve `/robots.txt` y `/sitemap.xml` para las 13 rutas públicas. Mantener respuestas iniciales con texto y enlaces completos. En Search Console, recomendar la propiedad de prefijo de URL y enviar el sitemap publicado, sin afirmar que Google ya actualizó sus resultados.

## Diseño

- **Movimiento de diseño:** editorial contemporáneo y minimalista, inspirado en la presencia clara de Mónobo Editorial/letrame y la web SITE123 actual de Búho, con una composición cálida, joven y de confianza.
- **Principios:** claridad comercial sin letra pequeña; tipografía legible; libertad visual para los autores; interacción sencilla y accesible con controles explícitos.
- **Filosofía cromática:** azul profundo `#0b2433` para confianza y lectura, azules `#a3bfd5` y `#5b97ba` para calma/diálogo, blanco para aire y ámbar `#f2a900` para destacar acciones y vuelo. Conservar exactamente esta paleta en páginas públicas, favicon de fondo claro y administración.
- **Paradigma de layout:** menú flotante tipo píldora, hero editorial centrado, bloques alternados y tarjetas con esquinas suaves; panel de edición con navegación lateral compacta y vista previa amplia.
- **Motivos distintivos:** logo de búho compartido; seis siluetas negras de aves en Paquetes; iconografía editorial vectorial propia; ilustraciones y fotos reales con intención editorial.
- **Interacción y animación:** transición breve y suave; hover/focus visibles; soporte móvil/tableta/escritorio; `prefers-reduced-motion`; formularios con consentimiento visible, guardado de borrador y confirmación de publicación.
- **Tipografía:** Sora para titulares y navegación, Inter para cuerpo y formularios; jerarquía fuerte y metadatos con título, description e imagen adecuados por ruta.
- **Esencia de marca:** editorial cercana y accesible para autores hispanohablantes emergentes, con control editorial transparente y derechos de obra del autor; personalidad joven, cuidadosa y honesta.
- **Voz:** cercana, concreta, confiable, sin prometer ventas, tirajes o plazos no garantizados. Ejemplos: «Tu libro, a tu ritmo y con los derechos en tus manos»; «Cuéntanos tu idea; primero la leemos contigo».
- **Logotipo/wordmark:** símbolo de búho proporcionado, acompañado del wordmark «Búho Editorial»; favicon derivado del mismo símbolo en cuadrado para buscadores.
- **Color de marca distintivo:** azul profundo `#0b2433`.

## Estructura de archivos

- `index.html`, `servicios/`, `paquetes/`, `nosotros/`, `contacto/`, `libros/`, `blog/`, `terminos/`, `aviso-privacidad/`: páginas públicas multipágina.
- `src/secondary-pages.js` y `src/generate-secondary-pages.js`: contenido y generación de artículos/páginas estáticas.
- `src/main.js`, `src/styles.css`: navegación, interacciones, formulario y estilos responsive.
- `admin/index.html`, `src/admin.js`, `src/admin.css`: consola privada responsive.
- `server.js`, `server/`: sesión, endpoints públicos, control de acceso, validación, base de datos, migración y almacenamiento gestionado.
- `data/default-content.json`: semilla pública inicial, nunca con credenciales.
- `public/images/`: marca, iconos propios y recursos de imagen locales; referencias administradas estables permanecen bajo `/manus-storage/`.
- `public/manus-routes.json`: sólo manifiesto de páginas reales; excluir APIs, archivos, callback OAuth y rutas exclusivas de indexación.
- `public/favicon.ico`, `public/favicon.png`, `public/apple-touch-icon.png`, `public/site.webmanifest`: imagen/iconos de marca.
- `Dockerfile`, `vite.config.js`, `package.json`/lockfile: build estático, salida y runtime.

## Publicación y dependencias

El build estático sigue siendo `npm ci && npm run build` en `dist`. El contenedor Node escucha `PORT` (3000 por defecto), sirve páginas y activos y ofrece `/_app/health` sin autenticación. Mantener los campos de configuración y auto-publicación actualmente habilitados; no cambiar claves ni servicios. La autorización para publicar ya se concedió para las versiones anteriores; tras el nuevo checkpoint verificar si `auto_publish` completa la implementación. Si no, respetar cualquier nueva tarjeta de confirmación. Separar visualmente en el panel guardar borrador y publicar. Verificar por HTTP el HTML inicial, las rutas, favicon/manifiesto y una ruta inexistente; compilar, inspeccionar escritorios y breakpoints, y auditar el acceso al panel sin escribir datos de prueba en la base compartida.

## Actualización: identidad SEO de Búho Editorial (12 de octubre de 2026)

- Se añadió `src/apply-site-seo.js`, incorporado a `prebuild`, para mantener el nombre de sitio y metadatos de marca en las 13 rutas públicas sin duplicar páginas: título y descripción solicitados para Inicio; títulos/descripciones específicos por sección; `application-name`, `apple-mobile-web-app-title`, `og:site_name`, Open Graph y Twitter Cards, y JSON-LD `Organization`/`WebSite`.
- Se agregó al inicio el párrafo descriptivo solicitado y se conservó el token de Google Search Console proporcionado por el usuario.
- Se derivaron, sin modificar el logo original, `favicon.ico`, `favicon.png`, variantes de 192 y 512 px, `apple-touch-icon.png` y `site.webmanifest` a partir del logo existente.
- Se confirmó el dominio del despliegue y el build agrega en cada ruta su URL canónica y `og:url`; usa URLs absolutas en JSON-LD. Robots y sitemap los sirve el gateway en el dominio canónico, sin generar archivos estáticos.
- La petición de consentimiento para obtener `BUHO_ADMIN_EMAIL` fue cancelada desde la tarjeta del sistema; por tanto, no se implementa ni se expone un acceso administrativo sin autenticar. El desarrollo del panel y sus APIs persistentes queda pendiente hasta reanudar la autorización segura.

## Dominio público confirmado (12 de octubre de 2026)

- El aviso del despliegue del proyecto y una visita en línea confirmaron `https://buhoeditoria-zuqkghpp.manus.space/` como URL pública.
- La respuesta de `/robots.txt` permite indexar el sitio y declara `https://buhoeditoria-zuqkghpp.manus.space/sitemap.xml`; el gateway genera el sitemap con las 13 rutas del proyecto. No se necesita mantener copias estáticas de esos archivos.
- Las etiquetas `canonical`, `og:url` y las URLs `url` de JSON-LD deben usar ese origen público exacto, nunca el host interno de Preview.

## Datos confirmados: fundador e ISBN en Colombia (12 de octubre de 2026)

- El fundador es Styven Mogrovejo, confirmado expresamente por el usuario. Reutilizar su retrato ya facilitado; no inventar edad ni otros datos personales.
- La Cámara Colombiana del Libro publica tarifas vigentes desde el 16 de enero de 2026: COP $81.600 por ISBN impreso y COP $81.600 por ISBN digital, cada valor con COP $68.571 antes de IVA y COP $13.029 de IVA. Las versiones impresa y digital requieren ISBN distintos; la cifra puede cambiar, por lo que el sitio debe recomendar confirmar la tarifa antes de pagar.
- La solicitud debe presentarse a nombre de la persona o entidad legal y económicamente responsable de la publicación, no a nombre de un proveedor editorial contratado. La Cámara indica hasta dos días hábiles desde el pago si la información está correcta. Distinguir la tasa oficial del costo total del servicio editorial y describir el acompañamiento como orientación.
- Fuente primaria y tarifa: https://camlibro.com.co/isbn/ (Agencia Colombiana del ISBN, “Tarifas ISBN 2026”). Corroboración independiente: https://stilo.media/blog/isbn-colombia-como-obtenerlo (guía colombiana publicada el 25 de septiembre de 2026).
- La producción respondió con precisión diferente por ruta a los iconos: el PNG `/favicon-512.png` se entrega correctamente como cuadrado 512×512; el `/favicon.ico` de producción carga por la capa reservada del gateway una imagen rectangular 1400×1009, así que el generador debe preferir el PNG cuadrado y omitir un enlace explícito al ICO.
