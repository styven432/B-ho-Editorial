import { defineConfig } from 'vite';
import { resolve } from 'node:path';

export default defineConfig({
  appType: 'mpa',
  base: '/',
  server: {
    host: '0.0.0.0',
    port: 3000,
    strictPort: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 3000,
    strictPort: true,
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        home: resolve(import.meta.dirname, 'index.html'),
        servicios: resolve(import.meta.dirname, 'servicios/index.html'),
        paquetes: resolve(import.meta.dirname, 'paquetes/index.html'),
        libros: resolve(import.meta.dirname, 'libros/index.html'),
        blog: resolve(import.meta.dirname, 'blog/index.html'),
        blogManuscrito: resolve(import.meta.dirname, 'blog/como-preparar-tu-manuscrito/index.html'),
        blogAmazon: resolve(import.meta.dirname, 'blog/publicar-en-amazon/index.html'),
        blogIsbn: resolve(import.meta.dirname, 'blog/que-es-isbn/index.html'),
        blogDerechos: resolve(import.meta.dirname, 'blog/proteger-tus-derechos/index.html'),
        nosotros: resolve(import.meta.dirname, 'nosotros/index.html'),
        contacto: resolve(import.meta.dirname, 'contacto/index.html'),
        privacidad: resolve(import.meta.dirname, 'aviso-privacidad/index.html'),
        terminos: resolve(import.meta.dirname, 'terminos/index.html'),
      },
    },
  },
});
